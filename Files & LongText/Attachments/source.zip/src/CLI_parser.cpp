#include "CLI_parser.h"
#include <CLI11/CLI11.hpp>
#include <vector>
#include "counter.h"
#include "filter.h"

CLI_parser::CLI_parser(int argc, char** argv, Filter& f) : argc(argc), argv(argv), filter(f) {
    app.description("CodeLines counter");
    app.add_option("-l, --language", input_language)
        ->description("the language of your project directory you wanna parse, use \",\" to separate.")
        ->required()
        ->take_all()
        ->ignore_case()
        ->check([this](const std::string& val) -> std::string {
            if (!filter.language_.contains(val)) {
                std::string allowed;
                for (const auto& [key, _] : filter.language_) {
                    if (!allowed.empty())
                        allowed += ", ";
                    allowed += key;
                }
                return "value " + val + " is invalid(allowed: " + allowed + ")";
            }
            return "";
        }, "is_allowed_language?");
    app.add_option("-f, --filepath", input_filepath)
        ->description("input the file or directory you wanna count.")
        ->required()
        ->take_all()
        ->check([](const std::string& val) -> std::string {
            if (!fs::exists(val))
                return std::string("your -f, --filepath is not exist.");
            return std::string();
        }, "is_exist_file_or_directory?");
    app.add_flag("--include-doc", include_doc, "decide count doc files or not(" + CLI::detail::join(filter.file_type_["data"], ", ") + ")")
        ->default_val(false)
        ->ignore_case();
    app.add_flag("--include-data", include_data, "count data files or not(" + CLI::detail::join(filter.file_type_["data"], ", ") + ")")
        ->default_val(false)
        ->ignore_case();
    app.add_flag("--include-config", include_config, "count config files or not(" + CLI::detail::join(filter.file_type_["config"], ", ") + ")")
        ->default_val(false)
        ->ignore_case();
}

int CLI_parser::start() {
    CLI11_PARSE(app, argc, argv);
    filter.input_language_ = input_language;
    if(include_doc){
        for(const auto& type : filter.file_type_["doc"]){
            filter.input_file_type_.emplace_back(type);
        }
    }
    if(include_data){
        for(const auto& type : filter.file_type_["data"]){
            filter.input_file_type_.emplace_back(type);
        }
    }
    if(include_config){
        for(const auto& type : filter.file_type_["config"]){
            filter.input_file_type_.emplace_back(type);
        }
    }
    for(const auto& path : input_filepath){
        Counter counter(path, filter);
        display(counter.get_result(path));
    }
    return 1;
}

void CLI_parser::display(const std::pair<fs::path, std::vector<FileInfo>>& result) const {
    const auto& [dir_name, res] = result;
    std::cout << std::left << fs::path(dir_name).generic_string() << '\n';
    std::cout << std::setw(20) << std::left << "name" << std::setw(80) << std::left << "path" << std::setw(10) << std::left << "words" << std::setw(10) << std::left << "lines" << std::endl;
    std::string separate_line(120, '-');
    std::cout << separate_line << std::endl;
    size_t words_sum = 0, lines_sum = 0;
    for(const auto& item : res){
        std::cout << std::setw(20) << std::left << item.file_name_ << std::setw(80) << std::left << item.file_path_ << std::setw(10) << std::left << item.words_ << std::setw(10) << std::left << item.lines_ << std::endl;
        words_sum += item.words_;
        lines_sum += item.lines_;
    }
    std::cout << std::setw(20) << std::left << "sum: " << std::setw(80) << std::left << " " << std::setw(10) << std::left << words_sum << std::setw(10) << std::left << lines_sum << std::endl;
}
