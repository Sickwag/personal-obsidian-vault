# print("hello world")

# #占位符实际应用

# name = "Sickwag"
# message = "Stupid Rookie is %s" %name
# print(message)

# name = "Sickwag_1"
# age = 20
# message = "there was a guy named %s ,and he was a %s old man." % (name,age)
# print(message)


# #格式化精度控制
# Pi = 3.1415926535
# print("the Pi acuracy is %5.4d" %Pi)

# #快速格式化

# data_now = 20240711
# time_now = 1709
# print(f"now the data is {data_now} and the time is {time_now}.")

# #对表达式进行格式化

# money = 100
# spend = 10
# print(f"i have {money}$ and then spend {spend}$,i have Sickewleft with {money - spend}")

# #股价计算小程序

# name = "Tencent"
# stock_price = 19.99
# stock_code = 123456
# daily_growth = 1.2
# growth_days = 7
# print(f"Company: {name} \tstock code:{stock_code} \tcurrent stock price:{stock_price}")
# print("daily growth:%.1f\t,after 7 days ,the finnal stock price is %4.2f" %(daily_growth,stock_price*(daily_growth**7)))
# #print(f"daily growth:{daily_growth}\t,after 7 days ,the finnal stock price is {stock_price*(daily_growth**7)}")


# #布尔类型和比较运算符

# name_1 = "Troye"
# name_2 = "Troye"
# print("the result is %s" %(name_1==name_2))

# #IF语句的基本格式

# age = int(input("please input your age :"))
# if age >= 18:
#     print("you are an adult , please check your ticket and rejoy now .")
# print("you are under 18 years-old , you re free to play !")




# #if else 语句
# age = int(input("please input your age :"))
# if age >= 18:
#     print("you are an adult , please check your ticket and rejoy now .")
# else
#     print("you are under 18 years-old , you re free to play !")


# print("welcome to the amusement park !\n")
# height = int(input("please input your height :"))
# if height >= 120:
#     print("unfortunatly , your height is over 120 cm , you must have a ticket.")
# else :
#     print("your height is under 120cm , therefore you re free to play !")


#if elif else 判断语句

#猜数字游戏

# import random
# randomnum = random.randint(1,10)
# attemps = 3
# print("welcome to the number guessing game !\n you have 3 attempts to guess the secret number .")
# while attemps > 0 :
#     guess = int(input("please input your guess number :"))
#     if guess == randomnum :
#         print("Congratulations! you have guess right in %d attempts!"%(4-attemps))
#     else :
#         attemps -= 1
#         if attemps > 0 and guess > randomnum:
#             print("your guess num is bigger than the secret number try again .")
#         elif attemps > 0 and guess < randomnum:
#             print("your guess num is smaller than the secret number try again .")
#         else :
#             print("sorry you have run out all attempts you have ")
        


#判断语句的嵌套

# age = int(input("please input your age : "))
# if age >= 18:
#     print("your age is qualified .")
#     work_time = int(input("please input your work time "))
#     if work_time > 2 :
#         print("congradulations! you are qualified with a gift !")
#     else :
#         print("unfortunatly, your work time is not qualified.")
#         level = int(input("please input your level :"))
#         if level > 3:
#             print("but you are still enabled to take it .")
#         else :
#             print("Sorry , you are not qualified .")
# else:
#     print("your are too young child , maybe next time .")


# # 多条件满足任意多条即可

# print("this is a pre onboarding application questionaire .")
# # 获取应聘者信息
# university_degree = input("Do you have a university degree? (yes/no): ")
# gender = input("What is your gender? (male/female): ")
# weight = float(input("What is your weight in KG? "))
# height = float(input("What is your height in cm? "))

# # 判断应聘者是否符合公司招聘条件
# criteria_met = (university_degree == "yes") + (gender == "male") + (weight <= 75) + (height >= 175)

# # 输出结果
# if criteria_met >= 3:
#     print("Congratulations! You meet the criteria and are eligible for the job.")
# else:
#     print("Sorry, you do not meet the criteria for this position.")


# 表白100次

# i = 0
# while i < 100:
#     print("i like you , please be my girlfriend .")
#     i += 1

# 练习案例 求1——100的和

# i = 0
# count = 1
# while count <= 100:
#     i += count
#     count += 1
# print("1+2+3....+100 = {}".format(i))

# while 循环的基础案例 猜数字游戏

# import random
# num = random.randint(1,20)
# guess = 0
# attempt = 0
# while guess != num :
#     guess = int(input("please input your guess number :"))
#     if guess < num:
#         attempt += 1
#         print("your number is smaller than the secret num")
#     elif guess > num:
#         attempt +=1 
#         print("your number is bigger than the secret num")
# print("you got the right answer in {} attempts !".format(attempt+1))

# 表白问题  循环嵌套

# i = 1
# while i <= 100:
#     print(f"today is the {i} day ,preparing the confession....")
#     flower = 1
#     while flower <= 10 :
#         print("honey there are {} flower for you.".format(flower))
#         flower += 1
#     print("i like you .")
#     i += 1
# print("today is my {} day to confession , Success !".format(i-1))

# 嵌套案例 打印九九乘法表

# line = 1
# while line <= 9 :
#     column = 1 
#     while column <= line :
#         print(f"{column} * {line} = {line * column}\t",end = '')
#         column += 1
#     line += 1
#     print()

# for 循环基本语法格式

# name = "Sickwag"

# # for x in name :
#     print(f"{x}")

# 遍历循环练习，数一数有几个a

# word = "itheima is a brand of itcast"
# count = 0
# for tempoary in word :
#     if tempoary == "a":
#         count += 1
# print(f"the sentense has {count} a character(s)")


# range语句使用方法
# one parament in range

# for tempoary in range(10):
#     print(f"{tempoary}")

# #two paraments in range


# for tempoary in range(12,20):
#     print(f"{tempoary}")

# #three paraments 

# for tempoary in range(1,100,2):
#     print(f"{tempoary}")


# 有几个偶数

# count = 0
# for tempoary in range(1,100) :
#     if tempoary % 2 == 0 :
#         count += 1
# print(f"there are {count} even number(s) in this sentence.")

# 使用range循环编写送花表白问题

# for tempoary in range(1,101):
#     print(f"today is the {tempoary} day to confess ")
#     for flower in range(1,11):
#         print(f"honey , {flower} flower(s) there for you.")
#     print("i like you .")
# print("finnally i success in the 100 day !")

# for 循环打印九九乘法表

# for line in range(1,10):
#     for column in range(1,10):
#         if column <= line:
#             print(f"{line} * {column} = {line * column}\t",end='')
#     print()

# for line in range(1,10):
#     for column in range(1,line+1):
#             print(f"{column} * {line} = {line * column}\t",end='')
#     print()

# continue 和 break 语句执行

# for tempoary in range(1,4):
#     print("sentence 1") 
#     print("sentence 2") 
#     continue
#     print("sentence nodisplay") 
# print("sentence over")

# for tempoary in range(1,100):
#     print("sentence only one time")
#     break
#     print("sentence nodisplay ]")
# for tempoary in range(1,6):
#     print("sentence keep going 5 times")

# 发工资案例
# salary_in_sum = 10000
# for employee_num in range(1,21):
#     import random
#     degree = random.randint(1,10)
#     if degree >=5 :
#         salary_in_sum -= 1000
#         print(f"the employee {employee_num} will got salary 1000$ ,the balance left with {salary_in_sum}")
#         if salary_in_sum == 0 :
#             print("there has no money to spend out , next month maybe .")
#             break
#     else :
#         print(f"the employee {employee_num}'s degree {degree} lower than 5, got no mone , so next one ")

# 函数定义和使用方法

# 定义新函数计算字符串长度

# name1 = "Sickwag"
# name2 = "Shoil Dynasty"
# name3 = "Mashall"
# count = 0
# for tempoary in name1 :
#     count += 1
# print(count)
# count = 0
# for tempoary in name2 :
#     count += 1
# print(count)
# count = 0
# for tempoary in name3 :
#     count += 1
# print(count)

# def my_len(data):
#     count = 0
#     for index in data :
#         count += 1
#     print(count)

# my_len(name1)
# my_len(name2)
# my_len(name3)


# 定义函数相加

# def add(x,y):
#     z = x + y
#     print(z) 

# add(8,9)

# 定义函数 查核酸案例

# def check(temperature):
#     if temperature <= 37.5:
#         print(f"Your temperature is {temperature}. You need to be separated.")
#     else:
#         print(f"Your temperature is {temperature}. You are enabled.")

# temp = float(input("Please input your temperature: "))
# check(temp)

# def add(x,y):
#     """
#     这个函数是一个简单的把两个参数相加的函数
#     :param x: 参数x
#     :param y: 参数y
#     :return: 返回的和
#     """
#     z = x + y
#     print(z)
#     return z
#     print("i m done")

# add(5,6)

# 使用globa在函数内部改变全局变量

# num = 100
# def test_a():
#     global num
#     num = 200
#     print(num)
#     return num 

# test_a()

# 存取款机器提示代码


# money = 5000000
# name = input("please input your name :")
# def main_menu():
#     print("------main menu------")
#     print(f"Dear {name} ,welcome to ATM system,please select operation :")
#     print("check balance \t\t [input 1] ")
#     print("deposit \t\t [input 2] ")
#     print("withdrawal \t\t [input 3] ")
#     print("exit \t\t\t [input 4] ")
#     return input("please input your selection number :")
# def check_balance(show_header):
#     if show_header:
#         print("------checking deposit------")
#         # 因为每次进行查询操作之后都要显示余额，可以直接调用余额查询函数
#         # 余额函数会显示表头，可以通过不同定义函数的参数控制是否生成表头
#     print(f"dear {name},your account has left with {money}$")
# def deposit(num):
#     global money
#     money += num
#     print("------deposit------")
#     print(f"dear {name} ,you have deposit {num} successfully !")
#     check_balance(False)
#     #加上一句调用余额查询函数，但是表头显示参数为false
# def withdrawal(num):
#     global money
#     money -= num
#     print("------deposit------")
#     print(f"dear {name} ,you have withdrawal {num} successfully !")
#     check_balance(False)
# while True :
#     selection = main_menu()
#     if selection == "1":
#         check_balance(True)
#         continue
#     elif selection == "2":
#         num = int(input("please input the money you want deposit."))
#         deposit(num)
#         continue
#     elif selection == "3":
#         num = int(input("please input the money you want withdrawal."))
#         withdrawal(num)
#         continue
#     else :
#         print("exit")
#         break

# 使用列表元素
# name_list = ["string",123,153.26,True,[1,2,3,4,5]]
# print(name_list)
# print(type(name_list))


# 使用列表打印广播电话呼号

# def uppercase():
#     import string
#     letters = list(string.ascii_uppercase)  # 生成 A 到 Z 的字母列表
#     reverse_letters = list(reversed(letters))  # 反转字母列表
#     for i in range(len(reverse_letters) - 1):
#         print(reverse_letters[i], reverse_letters[i + 1], sep='\n')


# def radiowords():
#     words = ["Alpha", "Bravo", "Charlie", "Delta", "Echo", "Foxtrot", "Golf","Hotel", "India", "Juliett", "Kilo", "Lima", "Mike", "November", "Oscar", "Papa","Quebec", "Romeo", "Sierra", "Tango", "Uniform", "Victor","Whiskey", "X-ray", "Yankee", "Zulu"]

#     # 通过range函数反向输出单词并换行
#     for i in range(len(words) - 1, 0, -1):
#         print(words[i])

# print(uppercase = radiowords)

# def uppercase():
#     import string
#     letters = list(string.ascii_uppercase)  # 生成 A 到 Z 的字母列表
#     reverse_letters = list(reversed(letters))  # 反转字母列表
#     for i in range(len(reverse_letters)):
#         print(f"{reverse_letters[i]} = {radiowords(reverse_letters[i])}")

# def radiowords(letter):
#     words = {"A": "Alpha", "B": "Bravo", "C": "Charlie", "D": "Delta", "E": "Echo", "F": "Foxtrot", "G": "Golf",
#              "H": "Hotel", "I": "India", "J": "Juliett", "K": "Kilo", "L": "Lima", "M": "Mike", "N": "November",
#              "O": "Oscar", "P": "Papa", "Q": "Quebec", "R": "Romeo", "S": "Sierra", "T": "Tango", "U": "Uniform",
#              "V": "Victor", "W": "Whiskey", "X": "X-ray", "Y": "Yankee", "Z": "Zulu"}
    
#     return words.get(letter, "Not Found")

# uppercase()

# 嵌套列表

# name_list = [1,2,3,[4,5,6]]
# print(name_list[3][2])
# # 结果得到6

# 列表查询下标、修改、插入

# name_list = ["alpha","bravo","charile"]
# index = name_list.index("charile")
# print(index)
# # 结果为2，如果元素不存在就会报错

# name_list = ["alpha","bravo","charile"]
# name_list[2] = "delta"
# print(name_list[2])

# name_list = ["alpha","bravo","charile"]
# name_list.insert(1,"delta")
# print(name_list)

# name_list = ["alpha","bravo","charile"]
# name_list.extend(["delta","echo","foxtrot"])
# print(name_list)



# name_list = ["alpha","bravo","charile"]
# del name_list[2]
# print(name_list)

# name_list = ["alpha","bravo","charile"]
# extract = name_list.pop(2)
# new_name_list = name_list
# print(f"new_name_list is {name_list},and the extract element is {extract}")


# name_list = ["alpha","bravo","charile"]
# name_list.remove("charile")
# print(name_list)

# 使用统计功能


# name_list = ["alpha","bravo","charile","charile"]
# num = name_list.count("charile")
# print(num)

# name_list = ["alpha","bravo","charile","charile"]
# num = len(name_list)
# print(num)

# age_list = [21,25,21,23,22,20]
# age_list.append(31)
# print(age_list)
# age_list.extend([29,33,30])
# print(age_list)
# first = age_list[0]
# print(first)
# last = age_list[8]
# print(last)
# index = age_list.index(31) 
# # 注意查找的内容应该对应格式，不能查找“31”字符串31
# print(index)

# 遍历列表内的函数

# def list_while_func():
#     name_list = ["alpha", "bravo", "charlie", "delta"]
#     index = 0
#     while index < len(name_list):
#         element = name_list[index]
#         print(f"now print index {index}, it is {element}")
#         index += 1

# list_while_func()

# 使用for循环遍历

# name_list = ["alpha","bravo","charile","delta"]
# count = 0 
# for i in name_list:
#     print(f"now print {count} , it is {i}")
#     count += 1

# 练习案例：使用循环挑选相应数字

# number_list = [1,2,3,4,5,6,7,8,9,10]
# even_number_list = []
# odd_number_list = []
# order_number = 0
# element = number_list[order_number]
# while order_number < len(number_list):
#     if element % 2 == 0:
#         even_number_list.append(number_list[order_number])
#     element += 1
#     order_number += 1
# print(f"even number list is {even_number_list}")
# order_number = 0
# for index in number_list:
#     if index % 2 != 0 :
#         odd_number_list.append(number_list[order_number])
#     index +=1
#     order_number +=1
# print(f"odd number list is {odd_number_list}")

# t4 = ("hello")  # python认为字符串‘hello’是一个表达式，所以用（）也可以
# print(f"the type of t4 {type(t4)}")
# print(t4)

# 列表的嵌套更改

# t1 = (1,2,3,[4,5,6])
# print(f"before modification : {t1}")
# t1[3][0] = 6
# t1[3][1] = 5
# t1[3][2] = 4
# print(f"after modification : {t1}")

# 字符串的查找index
# name_str = "sickwag"
# print(name_str[0])
# print(name_str[-7])

# name_str = "sickwag"
# print(name_str.index("wag"))

# name_str = "sickwag"
# print(name_str.index("wat"))

# 字符串中替换

# name_str = "sickwag"
# print(name_str.replace("wag","wat"))
# print(name_str)

# 字符串的分割

# name_str = "s i c k w a g"
# new_name = name_str.split(" ")
# print(new_name)
# print(name_str)
# print(type(new_name))

# 字符串的规整

# name_str = "-------======there is a apple in the table-=-=-=-=-="
# print(f"finnal result is {name_str.strip("-=")}")

# 案例练习：分割字符串

# name_str = "itheima itcast boxuegu"
# print(name_str.count("it"))
# name_str_replace = name_str.replace(" ","|")
# print(name_str_replace)
# print(name_str_replace.split("|"))

# 数据切片联系案例

# # 获取 jklmno

# my_str = "abcdefghionmlkjpqrstuvwxyz"
# result1 = my_str[::-1][11:17]
# print(f"result1 is {result1}")

# my_str = "abcdefghionmlkjpqrstuvwxyz"
# result2 = my_str[9:15][::-1]
# print(f"result2 is {result2}")

# 集合的定义

# my_set = {"alpha","beta","charlie","alpha","beta"}
# print(f"the content of my_set is {my_set},\nthe type is {type(my_set)}")

# my_set = {"alpha","beta","charlie","alpha","beta"}
# my_set.add("delta")
# my_set.add("alpha")
# print(my_set)

# my_set.remove("delta")
# print(my_set)

# element = my_set.pop()
# print(f"the selected number is {element},after extract the set is {my_set}")

# my_set.clear()
# print(f"after clear the set is {my_set}")

# 取出两个集合的差集

# my_set1 = {"alpha","beta","charlie"}
# my_set2 = {"alpha","delta","echo"}
# my_set3 = my_set1.difference(my_set2)
# print(f"the set 1 is {my_set1},and set2 is {my_set2},and set3 is {my_set3}")

# my_set1 = {"alpha","beta","charlie"}
# my_set2 = {"alpha","delta","echo"}
# my_set4 = my_set1.difference_update(my_set2)
# print(f"my set4 is {my_set4}")

# my_set1 = {"alpha","beta","charlie"}
# my_set2 = {"alpha","delta","echo"}
# my_set3 = my_set1.union(my_set2)
# print(f"my set3 is {my_set3}")

# 集合的遍历

# my_set1 = {"alpha","beta","charlie","alpha"}
# for tempoary in my_set1:
#     print(tempoary)

# 集合练习案例

# my_list=['黑马程序员','传智播客','黑马程序员','传智播客','theima','itcast','itheima','itcast','best']
# my_set = set()
# for index in my_list:
#     my_set.add(index)
# print(f"set is {my_set}")

# 使用字典查询学生分数

# student_score_dict = {
#     "Alpha":{
#         "Chinese": 90,
#         "math": 80,
#         "English": 70},
#     "Beta":{"Chinese": 78,
#         "math":65,
#         "English":56},
#     "Charlie":{"Chinese": 67,
#         "math":99,
#         "English":89}}
# print(student_score_dict["Beta"]["English"])

# 修改\添加字典元素

# student_score_dict = {
#     "Alpha":{
#         "Chinese": 90,
#         "math": 80,
#         "English": 70},
#     "Beta":{"Chinese": 78,
#         "math":65,
#         "English":56},
#     "Charlie":{"Chinese": 67,
#         "math":99,
#         "English":89}}
# student_score_dict["Beta"]["English"] = 0
# print(student_score_dict["Beta"]["English"])

# 字典元素的取用和清空

# student_score_dict = {
#     "Alpha":{
#         "Chinese": 90,
#         "math": 80,
#         "English": 70},
#     "Beta":{"Chinese": 78,
#         "math":65,
#         "English":56},
#     "Charlie":{"Chinese": 67,
#         "math":99,
#         "English":89}}

# personal = student_score_dict.pop("Beta",None)
# print(personal)

# 获取字典中全部的key

# student_score_dict = {
#     "Alpha":{
#         "Chinese": 90,
#         "math": 80,
#         "English": 70},
#     "Beta":{"Chinese": 78,
#         "math":65,
#         "English":56},
#     "Charlie":{"Chinese": 67,
#         "math":99,
#         "English":89}}
# # 外层循环遍历学生的名字
# for student, scores in student_score_dict.items():
#     # 内层循环遍历每个学生对应的成绩字典
#     for subject, score in scores.items():
#         # 打印每个学生对应科目的成绩
#         print(f"{student}\t{subject}\t成绩是\t{score}")


# items()方法的使用

# 假设有一个字典
# my_dict = {'a': 1, 'b': 2, 'c': 3}

# # 使用 .items() 方法获取所有键值对
# items = my_dict.items()

# # 打印结果
# print(f"the result is {items}, and the type is {type(items)}")


# 升职加薪案例编写
# apartment = "apartment"
# salary = "salary"
# level = "level"
# techology = "techology"
# market = "market"
# information = {
#     "alpha":{
#         apartment : techology,
#         salary : 3000,
#         level : 1
#     },"beta":{
#         apartment : techology,
#         salary : 5000,
#         level : 2
#     },"charle":{
#         apartment : market,
#         salary : 5000 ,
#         level : 3
#     },"echo":{
#         apartment : techology,
#         salary : 4000,
#         level : 1
#     },"foxtrix":{
#         apartment :market,
#         salary : 6000,
#         level : 2
#     }
# }
# for name in information :
#     if information[name][level] == 1:
#         information[name][level] += 1
#         information[name][salary] += 1000
# print(information)


# 各种数据容器相互转换

# apartment = "apartment"
# salary = "salary"
# level = "level"
# techology = "techology"
# market = "market"
# information = {
#     "alpha":{
#         apartment : techology,
#         salary : 3000,
#         level : 1
#     },"beta":{
#         apartment : techology,
#         salary : 5000,
#         level : 2
#     },"charle":{
#         apartment : market,
#         salary : 5000 ,
#         level : 3
#     },"echo":{
#         apartment : techology,
#         salary : 4000,
#         level : 1
#     },"foxtrix":{
#         apartment :market,
#         salary : 6000,
#         level : 2
#     }
# }
# print(str(information))

# 字符串的大小比较

# print(f"string abcdef > d ? the result is {'abcdef'>'d'}")
# print(f"string de > d ? the result is {'de'>'d'}")

# 函数得多返回值

# def Sickwag():
#     return 1,"hello",True
# x,y,z = Sickwag()
# print(f"result is {x},type is {type(x)}")
# print(f"result is {y},type is {type(y)}")
# print(f"result is {z},type is {type(z)}")

# # 函数的参数定义方法
# def user_info(name, age ,gender):
#     print(f"the name of client is {name},{age}years old ,and a {gender} ")

# user_info("Sickwag",gender="male",age=21)

# def user_info(name, age ,gender="male"):
#     print(f"the name of client is {name},{age}years old ,and a {gender} ")

# user_info("Sickwag",age=21)
# user_info("Sickwag",age=21,gender="male")


# def user_info(name="Sickwag", age ,gender):
#     print(f"the name of client is {name},{age}years old ,and a {gender} ")
# user_info(name = "SIckwag",age=21, gender="male")# 这一行会报错

# 函数不定长参数

# # 位置不定长

# def user_info (*args):
#     print(f"the content is {args},and the type is {type(args)}")
# user_info(1,2,"Sickwag",True)

# # 关键字不定长


# def user_info (**kwargs):
#     print(f"the content is {kwargs},and the type is {type(kwargs)}")
# user_info(1,2,"Sickwag",True)# 这一行会报错
# user_info(name = "Sickwag",gender = "male",age = 20)

# 函数作为参数传递

# def test_func(compute):
#     result = compute(1,2) # 这里不能写return = compute(1,2)
#     # 因为return只是返回一个表示函数执行情况的信息
#     # 并没有打印出结果,要想得到反馈还是要print
#     print(f"type of compute is {type(compute)} \n result is {result}")
# def compute(x,y):
#     return x+y

# test_func(compute)

# 定义匿名函数
# def test_func(compute):
#     result = compute(1,2)
#     print(f"the result is {result}")

# test_func(lambda x,y : x+y)

# 文件的读取

# f = open("D:/test.txt","r",encoding="UTF-8")
# print(f"the type is {type(f)}")
# print(f"\nget 20 string in the file :{f.read(20)}")
# print(f"\nget the next 10 string in the file :{f.read(20)}")
# all_string = f.readlines()
# print(f"get all string in the file :{all_string}")

# readline 方法每次读取一行

# f = open("D:/test.txt","r",encoding="UTF-8")
# print(f"the type is {type(f)}")
# line1 = f.readline()
# line2 = f.readline()
# line3 = f.readline()
# print(f"the first line is {line1}")
# print(f"the second line is {line2}")
# print(f"the third line is {line3}")

# for循环遍历文件每一行

# i = 1
# for line in open("D:/test.txt","r",encoding="UTF-8"):
#     print(f"the {i} line contend is {line}")
#     i += 1
# 
# # 使用len统计长度

# print(len(open("D:/test.txt","r",encoding="UTF-8")))

# with open文件操作

# i = 1
# with open("D:/test.txt","r",encoding="UTF-8") as file :
#     for line in file:
#         print(f"the {i} line contend is {line}")
#         i += 1

# 文件操作案例

# method 1 通过遍历拆分后的字段找

# count = 0
# word_to_count = "itheima"
# with open("D:/test.txt","r",encoding="UTF-8") as file :
#     lined_file = list(file)
#     for line in lined_file:
#         words = line.split()
#         count += words.count(word_to_count)
# print(f"the string itheima has shown {count} times")

# method2 

# with open("D:/test.txt","r",encoding="UTF-8") as file :
#     lined_file = list(file)
#     num = 0
#     for line in lined_file:
#         words = line.split()
#         indice = [index for index, value in enumerate(words) if value == "itheima"]
#         num += len(indice)
# print(f"the string itheima has shown {num} times")

# method 3 

# with open("D:/test.txt","r",encoding="UTF-8") as file :
#     contend = file.read()
#     count = contend.count("itheima")
# print(f"the string itheima has shown {count} times")

# 文件的写入和追加操作

# f = file = open("D:/test2.txt","w") 
# f.write("Hello world !!!")
# f.close()

# f = file = open("D:/test2.txt","a") 
# f.write("Hello world !!!")
# f.close()

# 文件备份案例

# with open("D:/test3.txt", "r", encoding="UTF-8") as f:
#     # 打开备份文件，但在循环中仅打开一次
#     with open("D:/test3.txt.bak", "w", encoding="UTF-8") as f_backup:
#         for line in f:
#             elements = line.strip().split(",")  # 使用strip()去除可能的前后空白字符
#             if elements[4] == "正式":
#                 f_backup.write(line)  # 将符合条件的行写入备份文件


# with open("D:/test3.txt", "r", encoding="UTF-8") as file, open("D:/test3.txt.bak", "w", encoding="UTF-8") as file_back:
#     for line_list in file:
#         if line_list.strip().split(",")[4] == "正式":
#             file_back.write(line_list)

# 文件异常捕获

# try :
#     file = open("D:/abc.txt","r",encoding="UTF-8") #单独写这一行代码会报错
# except :
#     print("the file doesn't exist, open with ""w"" module ")
#     file = open("D:/abc.txt","w",encoding="UTF-8")


# try :
#     print(name)
# except (NameError, ZeroDivisionError) as e:
#     print(e) # 变量e记录下出现错误的错误内容说明,并不是错误的名称

# try :
#     print("name")
# except Exception as e: # 表示捕获所有异常
#     print(e) 
# else :
#     print("no Error !")
# finally :
#     print("all done !")

# 异常的传递性

# def func1():
#     print("func 1 start execute .")
#     num = 1 / 0
#     print("func 1 over execute .")
# # func1出现异常,
# def func2():
#     print("func 2 start execute .")
#     func1()
#     print("func 2 over execute .")
# # func2调用func1的时候出现异常
# def func3():
#     try :
#         func2()
#     except Exception as error :
#         print(f"the error is {error}")
# # func3调用func2出现异常
# # 因为每一个异常出现之后会停止执行函数,所以每一个print over信息不出现
# func3()# 调用func3函数返回错误信息

# 导入模块

# import time 
# print("Hello")
# time.sleep(5)
# print("World")

# from time import sleep
# print("Hello")
# sleep(5)
# print("World")


# from time import *
# print("Hello")
# sleep(5)
# print("World")

# import time as type
# print("Hello")
# type.sleep(5)
# print("World")

# from time import sleep as print
# print(5)
# print("Hello World")

# import my_module1
# my_module1.test(1,2)

# 不同模块中功能同名问题

# from my_module1 import test 
# from my_module2 import test
# test(1,2)

# 模组文件测试

# print(type(__name__))

# __all__ = ['test_A']
# def test_A():
#     print('testA')
# def test_B():
#     print('testB')

# from my_module1 import test_A
# test_A()

# 导入包

# import my_package.my_module1
# import my_package.my_module2
# my_package.my_module1.info_print1()
# my_package.my_module2.info_print2()

# from my_package import my_module1
# from my_package import my_module2
# my_package.my_module1.info_print1()
# my_package.my_module2.info_print2()

# from my_package.my_module1 import info_print1
# from my_package.my_module2 import info_print2
# info_print1()
# info_print2()

# 开发可视化图表

# json数据格式
# # 将Python中的列表转换为json格式
# import json
# my_list = [{"name" : "Sickwag"},{"gender" : "male"},{"age" : 20}]
# data = json.dumps(my_list)
# print(f"the type of date is {type(data)}")
# print(f"and the contend is {data}")

# # 将python中字典转换为json格式
# import json
# my_dictionary = {"name" : "Sickwag","gender" : "male","age" : 20}
# data = json.dumps(my_dictionary)
# print(f"the type of date is {type(data)}")
# print(f"and the contend is {data}")

# # 将json转化为列表
# import json
# json_str = '[{"name" : "Sickwag"},{"gender" : "male"},{"age" : 20}]'# 对json字符串文本使用单引号
# data = json.loads(json_str)
# print(f"the type of date is {type(data)}")
# print(f"and the contend is {data}")

# # 将json转化为字典
# import json
# json_str = '{"name" : "Sickwag","gender" : "male","age" : 20}'# 对json字符串文本使用单引号
# data = json.loads(json_str)
# print(f"the type of date is {type(data)}")
# print(f"and the contend is {data}")


# 可视化折线图

# from pyecharts.charts import Line
# from pyecharts.options import TitleOpts ,LegendOpts,ToolboxOpts,VisualMapOpts
# line = Line()
# line.add_xaxis(["June","July","August","Septemper"])
# line.add_yaxis("score",[60,70,80,90])
# line.set_global_opts(
#     title_opts=TitleOpts(title="The score change in a period",pos_left="center", pos_bottom="0.01"),# 将标题居中放在底部并显示
#     legend_opts=LegendOpts(is_show=True),
#     toolbox_opts=ToolboxOpts(is_show=True),
#     visualmap_opts=VisualMapOpts(is_show=True)
# )
# line.render() # 注意render的位置,提交了表格文件才会有变化

# # 数据处理  全国地图

# from pyecharts.charts import Map
# from pyecharts.options import VisualMapOpts

# # 创建地图对象
# map = Map()

# # 准备数据，每个元素是一个包含省份名称和数据值的字典
# data = [
#     {"name": "北京", "value": 99},
#     {"name": "江西", "value": 199},
#     {"name": "广东", "value": 299},
#     {"name": "湖南", "value": 399},
#     {"name": "河北", "value": 499}
# ]

# # 添加数据到地图
# map.add("test_map", data, "china")

# # 设置全局配置项，包括视觉映射组件
# map.set_global_opts(
#     visualmap_opts=VisualMapOpts(
#         is_show=True,
#         is_piecewise=True,  # 允许手动校准范围
#         pieces=[
#             {"min": 1, "max": 9, "label": "1-9", "color": "#CCFFFF"},
#             {"min": 10, "max": 99, "label": "10-99", "color": "#FF6666"},
#             {"min": 100, "max": 999, "label": "100-999", "color": "#CCFFFF"}
#             # 手动划分不同数据区域的颜色
#         ]
#     )
# )

# # 渲染地图
# map.render()


# sort方法对列表进行排序
# my_list = [["alpha",33],["beta",30],["charlie",25]]
# def choose_sort_key (element):
#     return element[1]
# my_list.sort(key = choose_sort_key,reverse=False)
# print(my_list)
