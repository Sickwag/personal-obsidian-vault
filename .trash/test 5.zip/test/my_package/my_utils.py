# def str_reverse(s):
#     indice = [(index,value) for index,value in enumerate(s)]
#     t = -1
#     for i in s:
#         print(indice[t][-1],end="")
#         t -= 1
# if __name__ == "__main__":
#     str_reverse("Sickwag")

# # 更简单的写法
# def str_reverse(s):
#     print(s[::-1])

# if __name__ == "__main__" :
#     s = "sickwag"
#     str_reverse(s)

# def substr(s,x,y):
#     return s[x:y]

# if __name__ == "__main__":
#     substr("Sickwag",1,2)