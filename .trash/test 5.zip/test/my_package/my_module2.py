# def test(a,b):
#     print(f"x minus y equal to {a - b} ")

def info_print2() :
    print("output of info_input_print2 function")