# def print_file_info(file_name):
#     try :
#         file = open(file_name,"r",encoding="UTF-8")# 如果输入的是文件路径可以不用""括起
#         print(file.readlines())
#     except Exception as e:
#         print(f"the file doen't exist, and {e}")
#     finally :
#         if file == None :
#             file.close()
# if __name__ == "__main__" :
#     print_file_info("D:/test.txt")

# def append_to_file(file_name,data):
#     file = open(file_name,"a",encoding="UTF-8")
#     file.write(data) 
#     ''' 
#     注意不要写成file.append 对文件进行追加也是写入操作
#     文件已经定义为a打开,所以写入操作是追加的写入操作
#     '''
# if __name__ == "__main__" :
#     append_to_file("D:/test.txt","sickwag"*10)