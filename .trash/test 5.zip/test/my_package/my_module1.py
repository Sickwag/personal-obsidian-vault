# def test(a,b):
#     print(f"x plus y equal to {a + b} ")

# def test_A():
#     print('testA')
# def test_B():
#     print('testB')

# if __name__ == "__main__":
#     test(1,2)

def info_print1() :
    print("output of info_input_print1 function")